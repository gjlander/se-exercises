# Step 1: Create variables:
name = "Garrett"
age = 30
height = 63.8

# Step 2: Print the variables:
print(name)
print(age)
print(height)

# Step 3: Check the type of the variables:
print(type(name))
print(type(age))
print(type(height))

# Step 4: Casting
age_str = str(age)
print("My name is " + name + " and I am " + age_str + " years old.")

# Bonus: Global Variable (Bonus)
global_message = "I'm global!"

def write ():
    global global_message 
    global_message = "I'm changed now!"

write()

print(global_message)