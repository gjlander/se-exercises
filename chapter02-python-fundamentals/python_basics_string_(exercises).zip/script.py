# Step 1: Create Strings
first_name = "Garrett"
last_name = "Lander"
bio="""I'm a web dev instructor for WBS Coding School learning Python! 
I had a brief intro in cs50, now diving into more!     """

# Step 2: Access Characters and Slice Strings
print(first_name[0])
print(last_name[-1])
print(bio[:10])

# Step 3: Loop Through a String
for char in first_name:
    print(char)

# Step 4: String Length
print(len(bio))

# Step 5: Check Substrings
print("Python" in bio)
print("Java" not in bio)

# Step 6: Modify Strings
print(first_name.upper())
print(last_name.lower())
print(bio.strip().replace("Python", "coding"))

# Step 7: Concatenate Strings
full_name = first_name + " " + last_name
full_name_f = f"{first_name} {last_name}"

print(full_name)
print(full_name_f)


# Step 8: String Formatting
print(f"Hello, my name is {full_name} and I love Python!")
print("My full name is {full_name} and I am {age} years old.".format(full_name=full_name, age=30))

# Step 9: Escape Characters
print("He said, \"Python's great!\"")

# Bonus: Use String Methods
print(bio.center(100))
print(full_name.count("a"))