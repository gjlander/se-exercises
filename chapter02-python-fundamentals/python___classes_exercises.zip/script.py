# Book class
class Book:
    def __init__(self, name, author, release_date):
        self.name = name
        self.author = author
        self.release_date = release_date
        self.read = False

class BookCollection:
    def __init__(self, books=[]):
        try:
            for book in books:
                if not isinstance(book, Book):
                    raise TypeError("Must be list of books")
            self.books = books
    
    def add_book(new_book):
            if not isinstance(book, Book):
                    raise TypeError("Must be list of books")
            self.books.append(new_book)
    def mark_as_read(self, book_name):
        


# Book collection class


# Test your code