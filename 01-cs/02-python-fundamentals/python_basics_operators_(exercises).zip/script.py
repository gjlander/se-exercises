# Step 1: Arithmetic Operators
a = 15
b = 4


# Perform arithmetic operations
print(a + b)
print(a - b)
print(a * b)
print(a / b)
print(a // b)
print(a % b)
print(a ** b)


# Step 2: Assignment Operators
# Modify x using assignment operators
x = 10

x += 5
print(x)

x -= 7
print(x)

x *= 2
print(x)

x /= 3
print(x)





# Step 3: Comparison Operators
# Compare a and b
print(a == b)
print(a != b)
print(a > b)
print(a < b)
print(a >= b)
print(a <= b)

# Step 4: Logical Operators
is_python_fun = True
is_java_fun = False

# Combine Boolean variables
print(is_python_fun and is_java_fun)
print(is_python_fun or is_java_fun)
print(is_python_fun  and not is_java_fun)

# Step 5: Identity Operators
list1 = [1, 2, 3]
list2 = list1

# Check identities
print(list1 is not list2)


# Check if list1 is list3
list3 = [1, 2, 3]
print (list1 is list3)
# Step 6: Membership Operators
text = "Python programming is fun!"

# Check membership
print("Python" in text)
print("Java" not in text)

# Step 7: Bitwise Operators (Bonus)
# Perform bitwise operations
c = 5
d = 3

print(c & d)
print(c | d)
print(c ^ d)
print(c << d)
print(c >> d)

# Step 8: Operator Precedence
# Write expressions with precedence
print(x + b * (c - d) / a ** 2)