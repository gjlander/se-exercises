#  1. Create a Set
fruits = {'apple', 'cherry', 'kiwi', 'orange', 'date'}

# 2. Check Membership
if 'cherry' in fruits:
    print('Popped your cherry!')
else:
    print("Couldn't find the cherry.")

# 3. Add and Update Items
fruits.add('banana')
print('after add: ', fruits)

more_fruits = {'blueberrry', 'blackberry', 'strawberry'}
fruits.update(more_fruits)

print('after update: ', fruits)

# 4. Remove Items
fruits.remove('banana')
print('after remove:', fruits)
fruits.discard('fig')
fruits.pop()
print('afer pop:', fruits)
copy = fruits.copy()
copy.clear()
print('after clear:', copy)

# 5. Set Operations 
set_a = {'apple', 'cherry', 'kiwi', 'orange', 'date'}
set_b = {'fig', 'passion fruit', 'pear', 'apple', 'date'}

ab_union = set_a.union(set_b)
print('ab_union:', ab_union)

ab_intersect = set_a.intersection(set_b)
print('ab_intersect:', ab_intersect)

only_a = set_a.difference(set_b)
print('only a:', only_a)

sym_diff = set_a.symmetric_difference(set_b)
print('sym_diff:', sym_diff)
# 6. In-place Set Operations
# set_b.difference_update(set_a)
# print('set_b after update:', set_b)

# set_b.intersection_update(set_a)
# print('set_b after intersect:', set_b)

set_a.update(set_b)
print('comb ab:', set_a)

# 7. Relational Methods
small_set = {1, 2, 3, 4, 5}
large_set = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
print(small_set.issubset(large_set))
print(large_set.issuperset(small_set))
print(small_set.isdisjoint(large_set))