# Step 1: Create and Print a List
dnd_classes = ['paladin', 'rogue', 'bard', 'cleric']
print('full array: ', dnd_classes)
# Step 2: Access Elements by Index and Negative Index
print('first item: ', dnd_classes[0])
print('last item: ', dnd_classes[-1])
print('3rd to last item: ', dnd_classes[-3])

# Step: 3 Slice a List
print('index 1-3 (excluding 3)', dnd_classes[1:3])
print('until 2 (exclusive): ', dnd_classes[:2])
print('from 2 until end (inclusive): ',dnd_classes[2:])

# Step 4: Check if an Item Exists
if 'fighter' in dnd_classes:
    print("Found the fighter! Straight!")
# Step 5: Add Items
else:
    dnd_classes.append('fighter')

dnd_classes.insert(1, 'ranger')

print('after append and insert: ', dnd_classes)

# Step 6: Change Items
dnd_classes[0] = 'warlock'
dnd_classes[2:4] = ['wizard', 'sorcerer']
print('after changes: ', dnd_classes)

# Step 7: Remove items
dnd_classes.remove('cleric')
dnd_classes.pop(1)
temp = [1, 2, 3, 4, 5]
temp.clear()
print('after removal: ', dnd_classes)
print('cleared temp: ', temp)

# Step 8: Copy a list
dnd_copy = dnd_classes.copy()
dnd_slice = dnd_classes[:]
dnd_classes.append('barbarian')
print('dnd_copy: ', dnd_copy)
print('dnd_slice: ', dnd_slice)
print('dnd_classes: ', dnd_classes)

# Step 9: Concatenate and Extend
missing_classes = ['cleric', 'bard', 'monk']

comb_classes = dnd_classes + missing_classes
print('concated classes: ',comb_classes)
dnd_classes.extend(missing_classes)
print('extended dnd classes: ', dnd_classes)
# Step 10: Sort and Reverse
dnd_classes.sort()
print("sorted asc: ", dnd_classes)
rev_classes = sorted(dnd_classes, reverse=True)
print('desc new classes: ', rev_classes)
# Count and Index
print(f"wizard count: {dnd_classes.count('wizard')}")
print(f"sorcerer index: {dnd_classes.index('sorcerer')}")

# List comprehension
dnd_chars = [cl.upper() for cl in dnd_classes ]
print("dnd_chars: ", dnd_chars)