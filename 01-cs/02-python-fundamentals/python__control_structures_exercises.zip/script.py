# 1. Basic If Condition
num = -3

if num > 0:
    print(f"{num} is positive")
elif num < 0:
    print(f"{num} is negative")
else:
    print(f"{num} is zero")

# 2. Grade Calculator
score = 93

if score > 100 or score < 0:
    print("Invalid score")
elif score >= 90:
    print("A")
elif score >= 80:
    print("B")
elif score >= 70:
    print("C")
elif score >= 60:
    print("D")
else:
    print("F")
# 3. Ternary Operator Practice
age = 19
status = "adult" if age > 18 else "minor"
print("status:", status)

# 4. For Loop over a List
vehicles = ["car", "jeep", "truck", "van"]

for vehicle in vehicles:
    print(f"{vehicle}")

# 5. For Loop with Conditions
for i in range(1, 10):
    if i % 2 != 0:
        continue
    print(i)

# 6. While Loop Summation
total = 0
index = 0
while index < 101:
    total += index
    index += 1
else:
    print(f"sum of all numbers up to 100:", total)

# 7. Break out of a Loop
for word in ["hi", "there", "monkey"]:
    if len(word) > 5:
        print(word)
        break
else:
    print("No words with more than 5 letters")

# 8. Nested Loops
people = ["Bob", "Anne", "Steve", "Willow"]
pets = ["dog", "cat", "rat", "hamster", "horse"]

for person in people:
    for pet in pets:
        print(f"{person} and {pet}")

# 9. Loop with Else Clause
for pet in pets:
    if (pet == "hamster"):
        print("We found the hamster!")
        break
else:
    print("No hamster found :(")
# 10. Pass Statement Usage
for person in people:
    pass

# 11. Pattern matching
fruits = ["kiwi", "apple", "orange", "date"]
veggies = ["carrot", "pea", "tomato", "broccoli"]
meat = ["pork", "beef", "ham", "sausage", "chicken"]

food = "beef"

match food:
    case str() as string if string in fruits:
        print("It's a fruit!")
    case str() as string if string in veggies:
        print("It's a veggie!")
    case str() as string if string in meat:
        print("It's  meat!")
    case _:
        print("Don't eat that!")