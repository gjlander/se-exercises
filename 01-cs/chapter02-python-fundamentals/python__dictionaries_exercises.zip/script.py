# 1. Create and Print a Dictionary
me = {
    "name": "Garrett",
    "age": 30,
    "city": "Berlin"
}
print("me:", me)
# 2. Access Dictionary Elements
print(me["name"])
print(me.get("email", "No email"))
print(list(me.keys()))
print(list(me.values()))
print(list(me.items()))

# 3. Check for Key Existence
if "age" in me:
    print("You're an old fuck, ain't ya?")
else:
    print("Timeless")

# 4. Change and Update Dictionary Elements
me["city"] = "Seattle"
me.update({"age": 31, "occupation": "web dev instructor"})
print(me)
# 7. Copy a Dictionary
me_copy = me.copy()
me_dict = dict(me)
# 5. Add New Items to the Dictionary
me["country"] = "Germany"
me.update({"hobby": "board games"})
 

# 6. Remove Items from the Dictionary
age = me.pop("age")
print(age)

last = me.popitem()
print(last)

del me["city"]
print(me)
print(me_copy)
print(me_dict)

# 8. Using setdefault()
print(me.setdefault("name"))
print(me.setdefault("kids", 0))