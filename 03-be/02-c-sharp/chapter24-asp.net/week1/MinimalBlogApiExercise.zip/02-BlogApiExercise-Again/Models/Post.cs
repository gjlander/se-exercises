using Microsoft.AspNetCore.Components.Web;

namespace BlogApi.Models;

public class Post
{
  public Guid Id { get; set; }
  public Guid UserId { get; set; }
  public string Title { get; set; } = string.Empty;
  public string Content { get; set; } = string.Empty;
  public DateTimeOffset? PublishedAt { get; set; }
}