# 1. Create a Tuple
my_tuple = (3, 6, 9, 12)

# 2. Print the Tuple
print('my_tuple: ', my_tuple)


# 3. Access Tuple Items
print('first item:', my_tuple[0])
print('last item:', my_tuple[-1])

# 4. Slice the Tuple
start_tuple = my_tuple[:2]
print('start:', start_tuple)
end_tuple = my_tuple[1:]
print('end tuple:', end_tuple)


# 5. Check if an Item Exists
if 15 in my_tuple:
    print('This goes up to or past 15!')
else:
    print('That number is too high :(')

# 6. Count and Index
print(f"{my_tuple.count(2)}")
print(f"{my_tuple.index(9)}")

# 7. Packing and Unpacking
num1, num2, num3, num4 = my_tuple
print(num1, num2, num3, num4)

(three, *mult_3) = my_tuple
print(three, mult_3)
# 8. Joining Tuples
next_mults = (15, 18, 21, 24)
joined_mults = my_tuple + next_mults
three_of_threes = joined_mults * 3
print(joined_mults)
print(three_of_threes)